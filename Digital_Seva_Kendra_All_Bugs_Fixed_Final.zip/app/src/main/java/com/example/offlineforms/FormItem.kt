package com.example.offlineforms

data class FormItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val htmlFile: String,
    val iconName: String,
    val category: String,
    val imageUrl: String = ""
)
