package com.example.offlineforms

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.example.offlineforms.databinding.ActivityMainBinding
import com.google.android.material.textfield.TextInputEditText
import org.json.JSONArray
import java.io.InputStreamReader

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val formList = mutableListOf<FormItem>()

    companion object {
        // Updated Master Password as requested by user
        private const val MASTER_PASSWORD = "5327"
        private const val BYPASS_TAP_THRESHOLD = 5
        private const val TAP_WINDOW_MS = 2500L
        private const val PERMISSION_REQUEST_CODE = 201

        // Session-wide unlock state: Once entered, app remains unlocked until fully closed/swiped away
        var isAppSessionUnlocked = false
    }

    private var passwordDialog: AlertDialog? = null
    private var profileTapCount = 0
    private var lastTapTime = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        loadFormsConfig()
        setupRecyclerView()
        setupProfileSecretBypass()
        checkAndRequestAppPermissions()

        if (!isAppSessionUnlocked) {
            showPasswordDialogIfNeeded()
        }
    }

    private fun checkAndRequestAppPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val permissionsNeeded = mutableListOf<String>()
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(Manifest.permission.CAMERA)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
                    permissionsNeeded.add(Manifest.permission.READ_MEDIA_IMAGES)
                }
            } else {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    permissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE)
                }
            }
            if (permissionsNeeded.isNotEmpty()) {
                ActivityCompat.requestPermissions(this, permissionsNeeded.toTypedArray(), PERMISSION_REQUEST_CODE)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Do NOT re-lock when returning from a form! Only show dialog if session is not yet unlocked
        if (!isAppSessionUnlocked) {
            showPasswordDialogIfNeeded()
        }
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)
    }

    private fun setupProfileSecretBypass() {
        binding.layoutProfileSection.setOnClickListener {
            val currentTime = System.currentTimeMillis()
            if (currentTime - lastTapTime > TAP_WINDOW_MS) {
                profileTapCount = 1
            } else {
                profileTapCount++
            }
            lastTapTime = currentTime

            if (profileTapCount >= BYPASS_TAP_THRESHOLD) {
                profileTapCount = 0
                isAppSessionUnlocked = true
                passwordDialog?.dismiss()
                passwordDialog = null
                Toast.makeText(this, "एडमिन बाईपास सक्रिय! स्वागत है, शिवम सिंह 03", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showPasswordDialogIfNeeded() {
        if (isAppSessionUnlocked) return
        if (passwordDialog?.isShowing == true) return

        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_password_lock, null)
        val edtPassword = dialogView.findViewById<TextInputEditText>(R.id.edtPassword)
        val btnUnlock = dialogView.findViewById<Button>(R.id.btnUnlock)
        val txtError = dialogView.findViewById<TextView>(R.id.txtPasswordError)

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)
            .create()

        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        btnUnlock.setOnClickListener {
            val enteredPassword = edtPassword.text?.toString()?.trim() ?: ""
            if (enteredPassword == MASTER_PASSWORD) {
                isAppSessionUnlocked = true
                txtError.visibility = View.GONE
                dialog.dismiss()
                passwordDialog = null
                Toast.makeText(this, "सत्यापन सफल! स्वागत है, शिवम सिंह 03", Toast.LENGTH_SHORT).show()
            } else {
                txtError.visibility = View.VISIBLE
                edtPassword.setText("")
                edtPassword.requestFocus()
            }
        }

        dialog.setOnKeyListener { _, keyCode, event ->
            if (keyCode == android.view.KeyEvent.KEYCODE_BACK && event.action == android.view.KeyEvent.ACTION_UP) {
                finishAffinity()
                true
            } else {
                false
            }
        }

        passwordDialog = dialog
        dialog.show()
    }

    private fun loadFormsConfig() {
        formList.clear()
        try {
            val assetManager = assets
            val inputStream = assetManager.open("forms.json")
            val reader = InputStreamReader(inputStream)
            val jsonString = reader.readText()
            reader.close()

            val jsonArray = JSONArray(jsonString)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                formList.add(
                    FormItem(
                        id = obj.optString("id", "form_$i"),
                        title = obj.optString("title", "अज्ञात फॉर्म"),
                        subtitle = obj.optString("subtitle", ""),
                        htmlFile = obj.optString("htmlFile", ""),
                        iconName = obj.optString("iconName", "ic_form_default"),
                        category = obj.optString("category", "General"),
                        imageUrl = obj.optString("imageUrl", "")
                    )
                )
            }
            binding.txtTotalFormsCount.text = "कुल ${formList.size} सेवाएँ"
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "कॉन्फ़िगरेशन लोड करने में त्रुटि: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    private fun setupRecyclerView() {
        val spanCount = if (resources.configuration.screenWidthDp >= 600) 3 else 2
        binding.rvForms.layoutManager = GridLayoutManager(this, spanCount)

        val adapter = FormAdapter(this, formList) { item ->
            openForm(item)
        }
        binding.rvForms.adapter = adapter
    }

    private fun openForm(item: FormItem) {
        if (!isAppSessionUnlocked) {
            showPasswordDialogIfNeeded()
            return
        }

        if (item.htmlFile.isBlank()) {
            Toast.makeText(this, "यह Form अभी उपलब्ध नहीं है।", Toast.LENGTH_SHORT).show()
            return
        }

        val intent = Intent(this, FormWebViewActivity::class.java).apply {
            putExtra(FormWebViewActivity.EXTRA_TITLE, item.title)
            putExtra(FormWebViewActivity.EXTRA_HTML_PATH, item.htmlFile)
        }
        startActivity(intent)
    }
}
