package com.example.offlineforms

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class FormAdapter(
    private val context: Context,
    private val forms: List<FormItem>,
    private val onItemClick: (FormItem) -> Unit
) : RecyclerView.Adapter<FormAdapter.FormViewHolder>() {

    companion object {
        private val executor = Executors.newFixedThreadPool(4)
        private val maxMemory = (Runtime.getRuntime().maxMemory() / 1024).toInt()
        private val cacheSize = maxMemory / 8
        private val memoryCache = object : LruCache<String, Bitmap>(cacheSize) {
            override fun sizeOf(key: String, bitmap: Bitmap): Int {
                return bitmap.byteCount / 1024
            }
        }
    }

    class FormViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imgIcon: ImageView = itemView.findViewById(R.id.imgFormIcon)
        val txtTitle: TextView = itemView.findViewById(R.id.txtFormTitle)
        val txtSubtitle: TextView = itemView.findViewById(R.id.txtFormSubtitle)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FormViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_form_card, parent, false)
        return FormViewHolder(view)
    }

    override fun onBindViewHolder(holder: FormViewHolder, position: Int) {
        val item = forms[position]
        holder.txtTitle.text = item.title

        if (!item.subtitle.isNullOrBlank()) {
            holder.txtSubtitle.visibility = View.VISIBLE
            holder.txtSubtitle.text = item.subtitle
        } else {
            holder.txtSubtitle.visibility = View.GONE
        }

        val iconResId = if (!item.iconName.isNullOrBlank()) {
            val resId = context.resources.getIdentifier(item.iconName, "drawable", context.packageName)
            if (resId != 0) resId else R.drawable.ic_form_default
        } else {
            R.drawable.ic_form_default
        }
        holder.imgIcon.setImageResource(iconResId)

        if (!item.imageUrl.isNullOrBlank()) {
            val cachedBmp = memoryCache.get(item.imageUrl)
            if (cachedBmp != null) {
                holder.imgIcon.setImageBitmap(cachedBmp)
            } else {
                holder.imgIcon.tag = item.imageUrl
                executor.execute {
                    try {
                        val url = URL(item.imageUrl)
                        val conn = url.openConnection() as HttpURLConnection
                        conn.connectTimeout = 4000
                        conn.readTimeout = 4000
                        conn.doInput = true
                        conn.connect()
                        val inputStream = conn.inputStream
                        val bitmap = BitmapFactory.decodeStream(inputStream)
                        inputStream.close()
                        conn.disconnect()

                        if (bitmap != null) {
                            memoryCache.put(item.imageUrl, bitmap)
                            (context as? Activity)?.runOnUiThread {
                                if (holder.imgIcon.tag == item.imageUrl) {
                                    holder.imgIcon.setImageBitmap(bitmap)
                                }
                            }
                        }
                    } catch (_: Exception) {
                        // Retain vector icon on network failure
                    }
                }
            }
        }

        holder.itemView.setOnClickListener {
            onItemClick(item)
        }
    }

    override fun getItemCount(): Int = forms.size
}
