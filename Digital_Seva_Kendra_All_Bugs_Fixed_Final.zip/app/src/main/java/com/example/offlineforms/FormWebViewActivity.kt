package com.example.offlineforms

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.MediaStore
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.offlineforms.databinding.ActivityFormWebViewBinding
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.Locale

class FormWebViewActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFormWebViewBinding
    private var formTitle: String = "फॉर्म विवरण"
    private var htmlFilePath: String = ""
    private var speechBridge: AndroidSpeechBridge? = null
    private var pendingPermissionRequest: PermissionRequest? = null
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null
    private var cameraCapturedUri: Uri? = null

    companion object {
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_HTML_PATH = "extra_html_path"
        private const val CAMERA_PERMISSION_CODE = 301
        private const val FILE_CHOOSER_REQUEST_CODE = 402
        private const val CAMERA_CAPTURE_REQUEST_CODE = 403
        private const val ASSET_HOST = "appassets.androidplatform.net"
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFormWebViewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        formTitle = intent.getStringExtra(EXTRA_TITLE) ?: getString(R.string.default_form_title)
        htmlFilePath = intent.getStringExtra(EXTRA_HTML_PATH) ?: ""

        speechBridge = AndroidSpeechBridge(this)

        ensureCameraPermission()
        setupTopBar()
        setupWebView()
        setupBackNavigation()
        loadLocalHtml()
    }

    private fun ensureCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_CODE)
        }
    }

    private fun setupTopBar() {
        binding.txtHeaderTitle.text = formTitle

        binding.btnBack.setOnClickListener {
            handleBackAction()
        }

        binding.btnHome.setOnClickListener {
            finish()
        }

        binding.btnPrint.setOnClickListener {
            triggerNativePrint()
        }

        binding.btnErrorBack.setOnClickListener {
            finish()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        binding.webView.apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                allowFileAccess = true
                allowContentAccess = true

                @Suppress("DEPRECATION")
                allowFileAccessFromFileURLs = true
                @Suppress("DEPRECATION")
                allowUniversalAccessFromFileURLs = true

                builtInZoomControls = true
                displayZoomControls = false
                useWideViewPort = true
                loadWithOverviewMode = true
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                cacheMode = WebSettings.LOAD_DEFAULT

                // Crucial for programmatic Web Audio and sound effects
                mediaPlaybackRequiresUserGesture = false
            }

            addJavascriptInterface(AndroidPrintBridge(this@FormWebViewActivity, this), "AndroidPrint")
            addJavascriptInterface(AndroidDownloaderBridge(this@FormWebViewActivity), "AndroidDownloader")
            speechBridge?.let { addJavascriptInterface(it, "AndroidSpeech") }

            webChromeClient = object : WebChromeClient() {
                // 1. Precise Camera vs Gallery Handling for Photo Uploads (<input type="file">)
                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    this@FormWebViewActivity.fileUploadCallback?.onReceiveValue(null)
                    this@FormWebViewActivity.fileUploadCallback = filePathCallback

                    val isCaptureRequested = fileChooserParams?.isCaptureEnabled == true

                    if (isCaptureRequested) {
                        // User clicked CAMERA button (<input capture="user"> or <input capture="environment">)
                        // Launch native camera directly to take a photo
                        try {
                            val photoFile = File(cacheDir, "cam_${System.currentTimeMillis()}.jpg")
                            val photoUri = FileProvider.getUriForFile(
                                this@FormWebViewActivity,
                                "${applicationContext.packageName}.fileprovider",
                                photoFile
                            )
                            cameraCapturedUri = photoUri

                            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                                putExtra(MediaStore.EXTRA_OUTPUT, photoUri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                            }
                            startActivityForResult(cameraIntent, CAMERA_CAPTURE_REQUEST_CODE)
                            return true
                        } catch (e: Exception) {
                            e.printStackTrace()
                            cameraCapturedUri = null
                        }
                    }

                    // User clicked GALLERY / Upload Photo button (<input type="file" accept="image/*">)
                    // Launch Gallery directly to pick from existing photos
                    val pickPhotoIntent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI).apply {
                        type = "image/*"
                    }
                    val getContentIntent = Intent(Intent.ACTION_GET_CONTENT).apply {
                        type = "image/*"
                        addCategory(Intent.CATEGORY_OPENABLE)
                    }

                    val chooserIntent = Intent.createChooser(getContentIntent, "गैलरी से फ़ोटो चुनें (Gallery / Photos)").apply {
                        putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(pickPhotoIntent))
                    }

                    return try {
                        startActivityForResult(chooserIntent, FILE_CHOOSER_REQUEST_CODE)
                        true
                    } catch (e: Exception) {
                        this@FormWebViewActivity.fileUploadCallback?.onReceiveValue(null)
                        this@FormWebViewActivity.fileUploadCallback = null
                        false
                    }
                }

                // 2. Handle camera and microphone access requests from WebRTC (getUserMedia)
                override fun onPermissionRequest(request: PermissionRequest?) {
                    runOnUiThread {
                        val resources = request?.resources ?: return@runOnUiThread
                        val needsCamera = resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)

                        if (needsCamera) {
                            if (ContextCompat.checkSelfPermission(this@FormWebViewActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                                request.grant(resources)
                            } else {
                                pendingPermissionRequest = request
                                ActivityCompat.requestPermissions(
                                    this@FormWebViewActivity,
                                    arrayOf(Manifest.permission.CAMERA),
                                    CAMERA_PERMISSION_CODE
                                )
                            }
                        } else {
                            request.grant(resources)
                        }
                    }
                }

                override fun onPermissionRequestCanceled(request: PermissionRequest?) {
                    super.onPermissionRequestCanceled(request)
                    if (pendingPermissionRequest == request) {
                        pendingPermissionRequest = null
                    }
                }

                override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                    AlertDialog.Builder(this@FormWebViewActivity)
                        .setTitle("सूचना")
                        .setMessage(message ?: "")
                        .setPositiveButton(android.R.string.ok) { _, _ -> result?.confirm() }
                        .setCancelable(false)
                        .show()
                    return true
                }

                override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                    AlertDialog.Builder(this@FormWebViewActivity)
                        .setTitle("पुष्टि करें")
                        .setMessage(message ?: "")
                        .setPositiveButton(android.R.string.ok) { _, _ -> result?.confirm() }
                        .setNegativeButton(android.R.string.cancel) { _, _ -> result?.cancel() }
                        .setCancelable(false)
                        .show()
                    return true
                }
            }

            webViewClient = object : WebViewClient() {
                // Intercept appassets.androidplatform.net so local assets are served securely over HTTPS
                // This satisfies Chromium WebRTC requirements for getUserMedia (Camera Front/Back)
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    val uri = request?.url ?: return null
                    if (uri.scheme.equals("https", ignoreCase = true) && uri.host.equals(ASSET_HOST, ignoreCase = true)) {
                        val path = uri.path?.removePrefix("/") ?: return null
                        if (path.startsWith("assets/")) {
                            val assetSubPath = path.removePrefix("assets/")
                            try {
                                val stream: InputStream = assets.open(assetSubPath)
                                val mimeType = getMimeTypeForPath(assetSubPath)
                                return WebResourceResponse(mimeType, "UTF-8", stream)
                            } catch (_: Exception) {}
                        }
                    }
                    return super.shouldInterceptRequest(view, request)
                }

                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    injectSpeechAndHelperPolyfills(view)
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    binding.progressBar.visibility = View.GONE
                    injectSpeechAndHelperPolyfills(view)
                }

                override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                    super.onReceivedError(view, request, error)
                    if (request?.isForMainFrame == true) {
                        if (url?.startsWith("https://$ASSET_HOST") == true) {
                            binding.webView.loadUrl("file:///android_asset/$htmlFilePath")
                        } else {
                            showErrorState()
                        }
                    }
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CAMERA_CAPTURE_REQUEST_CODE) {
            if (fileUploadCallback != null) {
                if (resultCode == Activity.RESULT_OK && cameraCapturedUri != null) {
                    fileUploadCallback?.onReceiveValue(arrayOf(cameraCapturedUri!!))
                } else {
                    fileUploadCallback?.onReceiveValue(null)
                }
                fileUploadCallback = null
                cameraCapturedUri = null
            }
        } else if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (fileUploadCallback != null) {
                val results = WebChromeClient.FileChooserParams.parseResult(resultCode, data)
                fileUploadCallback?.onReceiveValue(results)
                fileUploadCallback = null
            }
        }
    }

    private fun injectSpeechAndHelperPolyfills(view: WebView?) {
        view?.evaluateJavascript(
            """
            (function() {
                // 1. Android Native Print Integration
                window.print = function() {
                    if (window.AndroidPrint && window.AndroidPrint.printPage) {
                        window.AndroidPrint.printPage();
                    }
                };

                // 2. Full SpeechSynthesisUtterance Polyfill
                if (typeof window.SpeechSynthesisUtterance === 'undefined') {
                    window.SpeechSynthesisUtterance = function(text) {
                        this.text = text || '';
                        this.lang = 'hi-IN';
                        this.rate = 1.0;
                        this.pitch = 1.0;
                        this.onend = null;
                        this.onerror = null;
                        this.voice = null;
                    };
                }

                // 3. Full window.speechSynthesis Polyfill routed to Android Google TTS
                if (window.AndroidSpeech) {
                    var synthPolyfill = {
                        speaking: false,
                        paused: false,
                        pending: false,
                        speak: function(utterance) {
                            var text = '';
                            if (typeof utterance === 'string') {
                                text = utterance;
                            } else if (utterance && utterance.text) {
                                text = utterance.text;
                            }
                            if (text) {
                                window.AndroidSpeech.speak(text);
                            }
                            if (utterance && typeof utterance.onend === 'function') {
                                var durationMs = Math.max(2200, text.length * 90);
                                setTimeout(function() {
                                    try { utterance.onend(); } catch(e) {}
                                }, durationMs);
                            }
                        },
                        cancel: function() {
                            if (window.AndroidSpeech && window.AndroidSpeech.stop) {
                                window.AndroidSpeech.stop();
                            }
                        },
                        pause: function() {},
                        resume: function() {},
                        getVoices: function() {
                            return [{
                                voiceURI: 'hi-IN-Standard',
                                name: 'Hindi India',
                                lang: 'hi-IN',
                                localService: true,
                                default: true
                            }];
                        }
                    };

                    window.speechSynthesis = synthPolyfill;
                }

                // 4. Blob & Data URL Download Interception
                if (!window.__downloader_attached) {
                    window.__downloader_attached = true;
                    var origClick = HTMLAnchorElement.prototype.click;
                    HTMLAnchorElement.prototype.click = function() {
                        try {
                            var href = this.getAttribute('href') || this.href;
                            var fileName = this.getAttribute('download') || this.download || 'download_file';
                            if (href && href.indexOf('blob:') === 0) {
                                fetch(href)
                                    .then(function(res) { return res.blob(); })
                                    .then(function(blob) {
                                        var reader = new FileReader();
                                        reader.onloadend = function() {
                                            if (window.AndroidDownloader && window.AndroidDownloader.saveBase64) {
                                                window.AndroidDownloader.saveBase64(reader.result, fileName);
                                            }
                                        };
                                        reader.readAsDataURL(blob);
                                    })
                                    .catch(function(err) {
                                        console.error('Blob fetch error', err);
                                    });
                            } else if (href && href.indexOf('data:') === 0) {
                                if (window.AndroidDownloader && window.AndroidDownloader.saveBase64) {
                                    window.AndroidDownloader.saveBase64(href, fileName);
                                }
                            }
                        } catch(e) {}
                        return origClick.apply(this, arguments);
                    };
                }
            })();
            """.trimIndent(), null
        )
    }

    private fun getMimeTypeForPath(path: String): String {
        return when {
            path.endsWith(".html", ignoreCase = true) -> "text/html"
            path.endsWith(".css", ignoreCase = true) -> "text/css"
            path.endsWith(".js", ignoreCase = true) -> "application/javascript"
            path.endsWith(".png", ignoreCase = true) -> "image/png"
            path.endsWith(".jpg", ignoreCase = true) || path.endsWith(".jpeg", ignoreCase = true) -> "image/jpeg"
            path.endsWith(".svg", ignoreCase = true) -> "image/svg+xml"
            path.endsWith(".json", ignoreCase = true) -> "application/json"
            path.endsWith(".woff2", ignoreCase = true) -> "font/woff2"
            path.endsWith(".woff", ignoreCase = true) -> "font/woff"
            path.endsWith(".ttf", ignoreCase = true) -> "font/ttf"
            else -> "text/plain"
        }
    }

    private fun loadLocalHtml() {
        if (htmlFilePath.isBlank()) {
            showErrorState()
            return
        }

        binding.progressBar.visibility = View.VISIBLE
        binding.layoutError.visibility = View.GONE
        binding.webView.visibility = View.VISIBLE

        val secureUrl = "https://$ASSET_HOST/assets/$htmlFilePath"
        binding.webView.loadUrl(secureUrl)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                pendingPermissionRequest?.grant(pendingPermissionRequest?.resources)
                Toast.makeText(this, "कैमरा अनुमति सक्षम की गई", Toast.LENGTH_SHORT).show()
            } else {
                pendingPermissionRequest?.deny()
                Toast.makeText(this, "कैमरा अनुमति अस्वीकार की गई", Toast.LENGTH_SHORT).show()
            }
            pendingPermissionRequest = null
        }
    }

    private fun showErrorState() {
        binding.progressBar.visibility = View.GONE
        binding.webView.visibility = View.GONE
        binding.layoutError.visibility = View.VISIBLE
        binding.txtErrorMessage.text = "यह Form अभी उपलब्ध नहीं है।"
    }

    private fun triggerNativePrint() {
        try {
            val printManager = getSystemService(Context.PRINT_SERVICE) as? PrintManager
            val documentAdapter = binding.webView.createPrintDocumentAdapter(formTitle.replace(" ", "_"))
            val jobName = "${getString(R.string.app_name)} - $formTitle"
            printManager?.print(jobName, documentAdapter, PrintAttributes.Builder().build())
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "प्रिंट शुरू करने में असमर्थ: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                handleBackAction()
            }
        })
    }

    private fun handleBackAction() {
        if (binding.webView.canGoBack()) {
            binding.webView.goBack()
        } else {
            finish()
        }
    }

    override fun onDestroy() {
        fileUploadCallback?.onReceiveValue(null)
        fileUploadCallback = null
        cameraCapturedUri = null

        speechBridge?.shutdown()
        speechBridge = null

        binding.webView.apply {
            clearHistory()
            clearCache(false)
            loadUrl("about:blank")
            onPause()
            removeAllViews()
            destroy()
        }
        super.onDestroy()
    }

    class AndroidPrintBridge(private val activity: Activity, private val webView: WebView) {
        @JavascriptInterface
        fun printPage() {
            activity.runOnUiThread {
                try {
                    val printManager = activity.getSystemService(Context.PRINT_SERVICE) as? PrintManager
                    val adapter = webView.createPrintDocumentAdapter("Digital_Seva_Kendra_Print")
                    printManager?.print("Document_Print", adapter, PrintAttributes.Builder().build())
                } catch (e: Exception) {
                    Toast.makeText(activity, "प्रिंट त्रुटि: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    class AndroidDownloaderBridge(private val activity: Activity) {
        @JavascriptInterface
        fun saveBase64(base64Data: String, fileName: String) {
            activity.runOnUiThread {
                try {
                    val cleanFileName = if (fileName.isNotBlank()) fileName else "Document_${System.currentTimeMillis()}.pdf"
                    val base64Content = if (base64Data.contains(",")) {
                        base64Data.substringAfter(",")
                    } else {
                        base64Data
                    }
                    val bytes = Base64.decode(base64Content, Base64.DEFAULT)

                    val resolver = activity.contentResolver
                    val isPdf = cleanFileName.endsWith(".pdf", ignoreCase = true)
                    val mimeType = if (isPdf) "application/pdf" else "image/png"

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val contentValues = ContentValues().apply {
                            put(MediaStore.MediaColumns.DISPLAY_NAME, cleanFileName)
                            put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                            put(MediaStore.MediaColumns.IS_PENDING, 1)
                        }

                        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                        if (uri != null) {
                            resolver.openOutputStream(uri)?.use { os ->
                                os.write(bytes)
                                os.flush()
                            }
                            contentValues.clear()
                            contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                            resolver.update(uri, contentValues, null, null)
                            Toast.makeText(activity, "डाउनलोड पूर्ण: $cleanFileName (Downloads में सुरक्षित)", Toast.LENGTH_LONG).show()
                            return@runOnUiThread
                        }
                    }

                    val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    if (!downloadsDir.exists()) {
                        downloadsDir.mkdirs()
                    }
                    val destFile = File(downloadsDir, cleanFileName)
                    FileOutputStream(destFile).use { fos ->
                        fos.write(bytes)
                        fos.flush()
                    }
                    Toast.makeText(activity, "डाउनलोड पूर्ण: $cleanFileName (Downloads में सुरक्षित)", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(activity, "डाउनलोड त्रुटि: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    class AndroidSpeechBridge(private val activity: Activity) : TextToSpeech.OnInitListener {
        private var tts: TextToSpeech? = null
        private var isReady = false
        private val pendingQueue = mutableListOf<String>()
        private val toneGenerator = try { ToneGenerator(AudioManager.STREAM_MUSIC, 100) } catch (e: Exception) { null }

        init {
            activity.runOnUiThread {
                tts = TextToSpeech(activity.applicationContext, this)
            }
        }

        override fun onInit(status: Int) {
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(Locale("hi", "IN"))
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale.getDefault())
                }
                tts?.setSpeechRate(0.95f)
                tts?.setPitch(1.02f)
                isReady = true

                synchronized(pendingQueue) {
                    for (msg in pendingQueue) {
                        speak(msg)
                    }
                    pendingQueue.clear()
                }
            }
        }

        @JavascriptInterface
        fun speak(text: String) {
            activity.runOnUiThread {
                if (isReady && tts != null && text.isNotBlank()) {
                    val params = Bundle()
                    params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
                    tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "Speech_${System.currentTimeMillis()}")
                } else if (!isReady) {
                    synchronized(pendingQueue) {
                        pendingQueue.add(text)
                    }
                }
            }
        }

        @JavascriptInterface
        fun stop() {
            activity.runOnUiThread {
                tts?.stop()
            }
        }

        @JavascriptInterface
        fun playTone(toneType: String) {
            try {
                if (toneType == "error") {
                    toneGenerator?.startTone(ToneGenerator.TONE_SUP_ERROR, 350)
                } else {
                    toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 200)
                }
            } catch (_: Exception) {}
        }

        fun shutdown() {
            tts?.stop()
            tts?.shutdown()
            tts = null
            toneGenerator?.release()
        }
    }
}
